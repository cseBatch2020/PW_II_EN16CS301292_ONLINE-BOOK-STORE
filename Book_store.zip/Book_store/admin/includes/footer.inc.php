<div id="footer-wrap">
	<p id="legal">(c) 2020 OurSite. Design by <a href=""> Medicaps</a>.</p>
	</div>