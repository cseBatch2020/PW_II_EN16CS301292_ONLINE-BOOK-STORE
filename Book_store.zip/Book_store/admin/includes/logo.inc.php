<marquee  direction="right" behavior="alternate"><h1>Book Store</h1></marquee>
